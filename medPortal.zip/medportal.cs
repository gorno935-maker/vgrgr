using System.Globalization;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

var portal = new MedicalPortal();
portal.SeedDemoData();

while (true)
{
    PrintMenu();
    var choice = ReadString("");

    if (choice == "0")
    {
        Console.WriteLine("До свидания!");
        break;
    }

    try
    {
        switch (choice)
        {
            case "1": AddPatient(); break;
            case "2": AddDoctor(); break;
            case "3": ShowPatients(); break;
            case "4": ShowDoctors(); break;
            case "5": BookAppointment(); break;
            case "6": CancelAppointment(); break;
            case "7": ShowDoctorSchedule(); break;
            case "8": AddTest(); break;
            case "9": CreatePrescription(); break;
            case "10": PayForService(); break;
            case "11": SearchPatient(); break;
            case "12": ShowStatistics(); break;
            case "13": ChangeAppointmentStatus(); break;
            default: Console.WriteLine("Неизвестный пункт меню. Выберите число из списка."); break;
        }
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine($"Ошибка ввода: {ex.Message}");
    }
    catch (InvalidOperationException ex)
    {
        Console.WriteLine($"Операция невозможна: {ex.Message}");
    }

    Console.WriteLine();
    ReadString("Нажмите Enter, чтобы вернуться в меню...");
}

// ======================= Меню и действия =======================

void PrintMenu()
{
    Console.WriteLine();
    Console.WriteLine("========== MEDICAL PORTAL ==========");
    Console.WriteLine();
    Console.WriteLine("1. Добавить пациента");
    Console.WriteLine("2. Добавить врача");
    Console.WriteLine("3. Показать всех пациентов");
    Console.WriteLine("4. Показать всех врачей");
    Console.WriteLine("5. Записать пациента на приём");
    Console.WriteLine("6. Отменить запись");
    Console.WriteLine("7. Показать расписание врача");
    Console.WriteLine("8. Добавить медицинский анализ");
    Console.WriteLine("9. Создать медицинское назначение");
    Console.WriteLine("10. Оплатить услугу");
    Console.WriteLine("11. Поиск пациента");
    Console.WriteLine("12. Статистика портала");
    Console.WriteLine("13. Подтвердить / завершить приём (дополнительно)");
    Console.WriteLine("0. Выход");
    Console.WriteLine();
    Console.Write("Выберите действие: ");
}

void AddPatient()
{
    var name = ReadString("ФИО: ");
    var birth = ReadDate("Дата рождения (дд.мм.гггг): ");
    var phone = ReadString("Телефон: ");
    var email = ReadString("Email: ");
    var address = ReadString("Адрес: ");

    var patient = portal.AddPatient(name, birth, phone, email, address);
    Console.WriteLine($"Пациент добавлен. ID = {patient.PatientId}");
}

void AddDoctor()
{
    var name = ReadString("ФИО врача: ");
    var birth = ReadDate("Дата рождения (дд.мм.гггг): ");
    var specialization = ReadString("Специализация: ");
    var experience = ReadInt("Стаж (лет): ");
    var cabinet = ReadInt("Номер кабинета: ");
    var salary = ReadDecimal("Оклад (тг): ");

    Department? department = null;
    if (portal.Departments.Count > 0)
    {
        Console.WriteLine("Отделения:");
        foreach (var d in portal.Departments) Console.WriteLine($"  {d.DepartmentId}. {d.DepartmentName}");
        var depText = ReadString("ID отделения (Enter — без отделения): ");
        if (depText != "")
        {
            if (!int.TryParse(depText, out var depId) || portal.FindDepartmentById(depId) == null)
                Console.WriteLine("Отделение не найдено — врач будет добавлен без отделения.");
            else
                department = portal.FindDepartmentById(depId);
        }
    }

    var doctor = portal.AddDoctor(name, birth, specialization, experience, cabinet, salary, department);
    Console.WriteLine($"Врач добавлен. ID = {doctor.DoctorId}");
}

void ShowPatients()
{
    if (portal.Patients.Count == 0)
    {
        Console.WriteLine("Список пациентов пуст.");
        return;
    }
    foreach (var p in portal.Patients) p.DisplayInfo();
}

void ShowDoctors()
{
    if (portal.Doctors.Count == 0)
    {
        Console.WriteLine("Список врачей пуст.");
        return;
    }
    foreach (var d in portal.Doctors) d.DisplayInfo();
    Console.WriteLine();
    foreach (var dep in portal.Departments) dep.DisplayDoctors();
}

void BookAppointment()
{
    var patient = AskPatient();
    if (patient == null) return;
    var doctor = AskDoctor();
    if (doctor == null) return;

    var date = ReadDate("Дата приёма (дд.мм.гггг): ");
    var time = ReadTime("Время приёма (чч:мм): ");

    var appointment = portal.BookAppointment(patient, doctor, date, time, out var error);
    if (appointment == null)
    {
        Console.WriteLine(error);
        return;
    }
    Console.WriteLine("Запись создана:");
    appointment.DisplayAppointment();
}

void CancelAppointment()
{
    var appointment = AskAppointment();
    if (appointment == null) return;
    appointment.CancelAppointment();
    Console.WriteLine("Запись отменена. Время врача снова свободно.");
}

void ShowDoctorSchedule()
{
    var doctor = AskDoctor();
    if (doctor == null) return;
    var date = ReadDate("Дата (дд.мм.гггг): ");

    var schedule = doctor.GetSchedule(date);
    if (schedule.Count == 0)
    {
        Console.WriteLine($"У врача {doctor.FullName} на {date:dd.MM.yyyy} нет записей.");
        return;
    }
    Console.WriteLine($"Расписание врача {doctor.FullName} на {date:dd.MM.yyyy}:");
    foreach (var a in schedule) a.DisplayAppointment();
}

void AddTest()
{
    var patient = AskPatient();
    if (patient == null) return;
    var name = ReadString("Название анализа: ");
    var date = ReadDate("Дата анализа (дд.мм.гггг): ");
    var result = ReadString("Результат (Enter — пока нет): ");

    var test = portal.AddTest(patient, name, date, result);
    test.DisplayResult();
}

void CreatePrescription()
{
    var patient = AskPatient();
    if (patient == null) return;
    var doctor = AskDoctor();
    if (doctor == null) return;
    var medication = ReadString("Препарат: ");
    var dosage = ReadString("Дозировка: ");
    var days = ReadInt("Длительность курса (дней): ");

    var prescription = portal.AddPrescription(patient, doctor, medication, dosage, days);
    prescription.DisplayPrescription();
}

void PayForService()
{
    var patient = AskPatient();
    if (patient == null) return;

    if (portal.Services.Count == 0)
    {
        Console.WriteLine("Список услуг пуст.");
        return;
    }
    Console.WriteLine("Услуги:");
    foreach (var s in portal.Services) s.DisplayService();

    var serviceId = ReadInt("ID услуги: ");
    var service = portal.FindServiceById(serviceId);
    if (service == null)
    {
        Console.WriteLine($"Услуга с ID {serviceId} не найдена.");
        return;
    }

    var payment = portal.PayForService(patient, service);
    Console.WriteLine("Оплата прошла успешно:");
    payment.DisplayPayment();
}

void SearchPatient()
{
    Console.WriteLine("Искать по: 1 — ID, 2 — ФИО, 3 — телефону");
    var mode = ReadString("Ваш выбор: ");

    List<Patient> found;
    switch (mode)
    {
        case "1":
            var id = ReadInt("ID пациента: ");
            var byId = portal.FindPatientById(id);
            found = byId == null ? new List<Patient>() : new List<Patient> { byId };
            break;
        case "2":
            found = portal.SearchPatientsByName(ReadString("ФИО (или часть): "));
            break;
        case "3":
            found = portal.SearchPatientsByPhone(ReadString("Телефон (или часть): "));
            break;
        default:
            Console.WriteLine("Неизвестный способ поиска.");
            return;
    }

    if (found.Count == 0)
    {
        Console.WriteLine("Пациент не найден. Проверьте введённые данные и попробуйте ещё раз.");
        return;
    }
    Console.WriteLine($"Найдено пациентов: {found.Count}");
    foreach (var p in found) p.DisplayInfo();
}

void ShowStatistics()
{
    Console.WriteLine("----- Статистика портала -----");
    Console.WriteLine($"Пациентов:               {portal.PatientsCount}");
    Console.WriteLine($"Врачей:                  {portal.DoctorsCount}");
    Console.WriteLine($"Записей на приём:        {portal.AppointmentsCount}");
    Console.WriteLine($"Завершённых приёмов:     {portal.CompletedAppointmentsCount}");
    Console.WriteLine($"Сумма оплаченных услуг:  {portal.TotalPaidAmount:N0} тг");
}

void ChangeAppointmentStatus()
{
    var appointment = AskAppointment();
    if (appointment == null) return;
    var action = ReadString("1 — подтвердить, 2 — завершить: ");
    switch (action)
    {
        case "1":
            appointment.ConfirmAppointment();
            Console.WriteLine("Запись подтверждена.");
            break;
        case "2":
            appointment.CompleteAppointment();
            Console.WriteLine("Приём завершён.");
            break;
        default:
            Console.WriteLine("Неизвестное действие.");
            break;
    }
}

// ======================= Вспомогательные методы ввода =======================

Patient? AskPatient()
{
    var id = ReadInt("ID пациента: ");
    var patient = portal.FindPatientById(id);
    if (patient == null) Console.WriteLine($"Пациент с ID {id} не найден.");
    return patient;
}

Doctor? AskDoctor()
{
    var id = ReadInt("ID врача: ");
    var doctor = portal.FindDoctorById(id);
    if (doctor == null) Console.WriteLine($"Врач с ID {id} не найден.");
    return doctor;
}

Appointment? AskAppointment()
{
    var id = ReadInt("Номер записи: ");
    var appointment = portal.FindAppointmentById(id);
    if (appointment == null) Console.WriteLine($"Запись №{id} не найдена.");
    return appointment;
}

string ReadString(string prompt)
{
    Console.Write(prompt);
    return Console.ReadLine()?.Trim() ?? "";
}

int ReadInt(string prompt)
{
    while (true)
    {
        if (int.TryParse(ReadString(prompt), out var value)) return value;
        Console.WriteLine("Введите целое число.");
    }
}

decimal ReadDecimal(string prompt)
{
    while (true)
    {
        var text = ReadString(prompt).Replace(',', '.');
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out var value)) return value;
        Console.WriteLine("Введите число.");
    }
}

DateTime ReadDate(string prompt)
{
    while (true)
    {
        if (DateTime.TryParseExact(ReadString(prompt), "dd.MM.yyyy", CultureInfo.InvariantCulture,
                                   DateTimeStyles.None, out var value)) return value;
        Console.WriteLine("Неверный формат. Пример: 25.11.2026");
    }
}

TimeSpan ReadTime(string prompt)
{
    while (true)
    {
        if (TimeSpan.TryParseExact(ReadString(prompt), new[] { @"h\:mm", @"hh\:mm" },
                                   CultureInfo.InvariantCulture, out var value)) return value;
        Console.WriteLine("Неверный формат. Пример: 10:30");
    }
}

// ======================= КЛАССЫ =======================

// Проверки входных данных (инкапсуляция, задача 19)
internal static class Guard
{
    public static string NotEmpty(string? value, string field)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException($"Поле «{field}» не может быть пустым.");
        return value.Trim();
    }

    public static string Email(string? value)
    {
        var email = NotEmpty(value, "Email");
        if (!email.Contains('@') || email.StartsWith('@') || email.EndsWith('@'))
            throw new ArgumentException("Email указан некорректно.");
        return email;
    }

    public static int NonNegative(int value, string field)
    {
        if (value < 0) throw new ArgumentException($"Поле «{field}» не может быть отрицательным.");
        return value;
    }

    public static decimal NonNegative(decimal value, string field)
    {
        if (value < 0) throw new ArgumentException($"Поле «{field}» не может быть меньше нуля.");
        return value;
    }

    public static int Positive(int value, string field)
    {
        if (value <= 0) throw new ArgumentException($"Поле «{field}» должно быть больше нуля.");
        return value;
    }

    public static decimal Positive(decimal value, string field)
    {
        if (value <= 0) throw new ArgumentException($"Поле «{field}» должно быть больше нуля.");
        return value;
    }
}

// Задача 20: перечисления
public enum AppointmentStatus { Scheduled, Confirmed, Completed, Cancelled }
public enum PaymentStatus { Pending, Paid, Refunded }

// Задача 18: интерфейс
public interface IPayable
{
    decimal CalculatePayment();
}

// Задача 16: абстрактный класс
public abstract class Person
{
    private string _fullName = "";
    private DateTime _birthDate;

    public int Id { get; }

    public string FullName
    {
        get => _fullName;
        set => _fullName = Guard.NotEmpty(value, "ФИО");
    }

    public DateTime BirthDate
    {
        get => _birthDate;
        set
        {
            if (value.Date > DateTime.Today)
                throw new ArgumentException("Дата рождения не может быть в будущем (возраст не может быть отрицательным).");
            _birthDate = value.Date;
        }
    }

    protected Person(int id, string fullName, DateTime birthDate)
    {
        Id = id;
        FullName = fullName;
        BirthDate = birthDate;
    }

    public int GetAge()
    {
        var today = DateTime.Today;
        var age = today.Year - BirthDate.Year;
        if (BirthDate.Date > today.AddYears(-age)) age--;
        return age;
    }

    public abstract void DisplayInfo();
}

// Задачи 2, 17: пациент
public class Patient : Person
{
    private string _phoneNumber = "";
    private string _email = "";
    private string _address = "";
    private readonly List<Appointment> _appointments = new();

    public int PatientId => Id;

    public string PhoneNumber
    {
        get => _phoneNumber;
        set => _phoneNumber = Guard.NotEmpty(value, "Телефон");
    }

    public string Email
    {
        get => _email;
        set => _email = Guard.Email(value);
    }

    public string Address
    {
        get => _address;
        set => _address = Guard.NotEmpty(value, "Адрес");
    }

    // Композиция (задача 14): карта создаётся вместе с пациентом и не живёт отдельно от него
    public MedicalRecord MedicalRecord { get; }

    // Ассоциация 1 — 0..* (задача 11)
    public IReadOnlyList<Appointment> Appointments => _appointments;

    public Patient(int id, string fullName, DateTime birthDate, string phoneNumber, string email, string address)
        : base(id, fullName, birthDate)
    {
        PhoneNumber = phoneNumber;
        Email = email;
        Address = address;
        MedicalRecord = new MedicalRecord(id, this);
    }

    public void UpdateProfile(string phoneNumber, string email, string address)
    {
        var phone = Guard.NotEmpty(phoneNumber, "Телефон");
        var mail = Guard.Email(email);
        var addr = Guard.NotEmpty(address, "Адрес");
        _phoneNumber = phone;
        _email = mail;
        _address = addr;
    }

    internal void AddAppointment(Appointment appointment) => _appointments.Add(appointment);

    public override void DisplayInfo()
    {
        Console.WriteLine($"Пациент №{PatientId}: {FullName}, возраст: {GetAge()}, " +
                          $"тел.: {PhoneNumber}, email: {Email}, адрес: {Address}");
    }
}

// Задачи 3, 17, 18: врач
public class Doctor : Person, IPayable
{
    public static readonly TimeSpan WorkDayStart = new(9, 0, 0);
    public static readonly TimeSpan WorkDayEnd = new(18, 0, 0);

    private string _specialization = "";
    private int _experience;
    private int _cabinetNumber;
    private decimal _salary;
    private readonly List<Appointment> _appointments = new();

    public int DoctorId => Id;

    public string Specialization
    {
        get => _specialization;
        private set => _specialization = Guard.NotEmpty(value, "Специализация");
    }

    public int Experience
    {
        get => _experience;
        set => _experience = Guard.NonNegative(value, "Стаж");
    }

    public int CabinetNumber
    {
        get => _cabinetNumber;
        set => _cabinetNumber = Guard.Positive(value, "Номер кабинета");
    }

    public decimal Salary
    {
        get => _salary;
        set => _salary = Guard.NonNegative(value, "Зарплата");
    }

    // Ассоциация 1 — 0..* (задача 12)
    public IReadOnlyList<Appointment> Appointments => _appointments;

    public Doctor(int id, string fullName, DateTime birthDate, string specialization,
                  int experience, int cabinetNumber, decimal salary)
        : base(id, fullName, birthDate)
    {
        Specialization = specialization;
        Experience = experience;
        CabinetNumber = cabinetNumber;
        Salary = salary;
    }

    public void UpdateSpecialization(string newSpecialization) => Specialization = newSpecialization;

    // Оклад + 2% за каждый год стажа (не более 25 лет)
    public decimal CalculateSalary() => Salary + Salary * 0.02m * Math.Min(Experience, 25);

    public decimal CalculatePayment() => CalculateSalary();

    public static bool IsWorkingTime(TimeSpan time) => time >= WorkDayStart && time < WorkDayEnd;

    // Задача 7: свободен ли врач в указанные дату и время
    public bool IsDoctorAvailable(DateTime date)
    {
        if (!IsWorkingTime(date.TimeOfDay)) return false;
        return !_appointments.Any(a => a.Status != AppointmentStatus.Cancelled && a.StartDateTime == date);
    }

    public List<Appointment> GetSchedule(DateTime date) =>
        _appointments
            .Where(a => a.AppointmentDate.Date == date.Date && a.Status != AppointmentStatus.Cancelled)
            .OrderBy(a => a.AppointmentTime)
            .ToList();

    internal void AddAppointment(Appointment appointment) => _appointments.Add(appointment);

    public override void DisplayInfo()
    {
        Console.WriteLine($"Врач №{DoctorId}: {FullName}, {Specialization}, стаж: {Experience} лет, " +
                          $"кабинет: {CabinetNumber}, оклад: {Salary:N0} тг");
    }
}

// Задачи 4, 13: отделение (агрегация с Doctor)
public class Department
{
    private string _departmentName = "";
    private int _floor;
    private string _phoneNumber = "";
    private readonly List<Doctor> _doctors = new();

    public int DepartmentId { get; }

    public string DepartmentName
    {
        get => _departmentName;
        set => _departmentName = Guard.NotEmpty(value, "Название отделения");
    }

    public int Floor
    {
        get => _floor;
        set => _floor = Guard.NonNegative(value, "Этаж");
    }

    public string PhoneNumber
    {
        get => _phoneNumber;
        set => _phoneNumber = Guard.NotEmpty(value, "Телефон отделения");
    }

    public Doctor? HeadDoctor { get; set; }

    public IReadOnlyList<Doctor> Doctors => _doctors;

    public Department(int id, string name, int floor, string phoneNumber)
    {
        DepartmentId = id;
        DepartmentName = name;
        Floor = floor;
        PhoneNumber = phoneNumber;
    }

    public bool AddDoctor(Doctor doctor)
    {
        ArgumentNullException.ThrowIfNull(doctor);
        if (_doctors.Contains(doctor)) return false;
        _doctors.Add(doctor);
        return true;
    }

    public bool RemoveDoctor(Doctor doctor)
    {
        var removed = _doctors.Remove(doctor);
        if (removed && HeadDoctor == doctor) HeadDoctor = null;
        return removed;
    }

    public void DisplayDoctors()
    {
        Console.WriteLine($"Отделение «{DepartmentName}» (этаж {Floor}, тел. {PhoneNumber}), " +
                          $"заведующий: {HeadDoctor?.FullName ?? "не назначен"}");
        if (_doctors.Count == 0)
        {
            Console.WriteLine("  В отделении пока нет врачей.");
            return;
        }
        foreach (var d in _doctors) Console.WriteLine($"  - {d.FullName}, {d.Specialization}");
    }
}

// Задача 5: медицинская услуга
public class MedicalService
{
    private string _serviceName = "";
    private decimal _price;
    private int _duration;

    public int ServiceId { get; }

    public string ServiceName
    {
        get => _serviceName;
        set => _serviceName = Guard.NotEmpty(value, "Название услуги");
    }

    public string Description { get; set; }

    public decimal Price
    {
        get => _price;
        private set => _price = Guard.NonNegative(value, "Стоимость услуги");
    }

    // Длительность в минутах
    public int Duration
    {
        get => _duration;
        set => _duration = Guard.Positive(value, "Длительность");
    }

    public MedicalService(int id, string name, string description, decimal price, int durationMinutes)
    {
        ServiceId = id;
        ServiceName = name;
        Description = description ?? "";
        Price = price;
        Duration = durationMinutes;
    }

    public decimal CalculatePrice(int quantity = 1, decimal discountPercent = 0)
    {
        Guard.Positive(quantity, "Количество");
        if (discountPercent < 0 || discountPercent > 100)
            throw new ArgumentException("Скидка должна быть от 0 до 100%.");
        return Price * quantity * (1 - discountPercent / 100m);
    }

    public void UpdatePrice(decimal newPrice) => Price = newPrice;

    public void DisplayService()
    {
        Console.WriteLine($"Услуга №{ServiceId}: {ServiceName} — {Price:N0} тг, {Duration} мин. {Description}");
    }
}

// Задачи 6, 7, 8, 20: запись на приём
public class Appointment
{
    public int AppointmentId { get; }
    public Patient Patient { get; }
    public Doctor Doctor { get; }
    public DateTime AppointmentDate { get; }
    public TimeSpan AppointmentTime { get; }
    public AppointmentStatus Status { get; private set; }

    public DateTime StartDateTime => AppointmentDate.Date + AppointmentTime;

    private Appointment(int id, Patient patient, Doctor doctor, DateTime date, TimeSpan time)
    {
        AppointmentId = id;
        Patient = patient;
        Doctor = doctor;
        AppointmentDate = date.Date;
        AppointmentTime = new TimeSpan(time.Hours, time.Minutes, 0);
        Status = AppointmentStatus.Scheduled;
    }

    // Создаёт запись, если время допустимо и врач свободен. Иначе null и текст причины в error.
    public static Appointment? CreateAppointment(int id, Patient patient, Doctor doctor,
                                                 DateTime date, TimeSpan time, out string error)
    {
        error = "";
        ArgumentNullException.ThrowIfNull(patient);
        ArgumentNullException.ThrowIfNull(doctor);

        var start = date.Date + new TimeSpan(time.Hours, time.Minutes, 0);

        if (start < DateTime.Now)
        {
            error = "Нельзя записать пациента на прошедшее время!";
            return null;
        }
        if (!Doctor.IsWorkingTime(start.TimeOfDay))
        {
            error = $"Врач принимает с {Doctor.WorkDayStart:hh\\:mm} до {Doctor.WorkDayEnd:hh\\:mm}.";
            return null;
        }
        if (!doctor.IsDoctorAvailable(start))
        {
            error = "Врач уже занят на указанное время!";
            return null;
        }

        var appointment = new Appointment(id, patient, doctor, date, time);
        patient.AddAppointment(appointment);
        doctor.AddAppointment(appointment);
        return appointment;
    }

    public void ConfirmAppointment()
    {
        if (Status != AppointmentStatus.Scheduled)
            throw new InvalidOperationException("Подтвердить можно только запись со статусом «Запланирована».");
        Status = AppointmentStatus.Confirmed;
    }

    public void CompleteAppointment()
    {
        if (Status != AppointmentStatus.Scheduled && Status != AppointmentStatus.Confirmed)
            throw new InvalidOperationException("Завершить можно только активную запись.");
        Status = AppointmentStatus.Completed;
    }

    public void CancelAppointment()
    {
        if (Status == AppointmentStatus.Completed)
            throw new InvalidOperationException("Нельзя отменить уже завершённый приём.");
        if (Status == AppointmentStatus.Cancelled)
            throw new InvalidOperationException("Запись уже отменена.");
        Status = AppointmentStatus.Cancelled;
    }

    public string StatusText => Status switch
    {
        AppointmentStatus.Scheduled => "Запланирована",
        AppointmentStatus.Confirmed => "Подтверждена",
        AppointmentStatus.Completed => "Завершена",
        AppointmentStatus.Cancelled => "Отменена",
        _ => Status.ToString()
    };

    public void DisplayAppointment()
    {
        Console.WriteLine($"Запись №{AppointmentId}: {Patient.FullName} → {Doctor.FullName} " +
                          $"({Doctor.Specialization}), {StartDateTime:dd.MM.yyyy HH:mm}, статус: {StatusText}");
    }
}

// Задачи 9, 14: медицинская карта (создаётся только внутри Patient)
public class MedicalRecord
{
    private readonly List<string> _medicalHistory = new();

    public int RecordId { get; }
    public Patient Patient { get; }
    public string Diagnosis { get; private set; } = "Не установлен";
    public DateTime CreationDate { get; }
    public IReadOnlyList<string> MedicalHistory => _medicalHistory;

    internal MedicalRecord(int recordId, Patient patient)
    {
        RecordId = recordId;
        Patient = patient;
        CreationDate = DateTime.Now;
    }

    public void AddDiagnosis(string diagnosis)
    {
        Diagnosis = Guard.NotEmpty(diagnosis, "Диагноз");
        _medicalHistory.Add($"{DateTime.Now:dd.MM.yyyy}: поставлен диагноз «{Diagnosis}»");
    }

    public void UpdateHistory(string note)
    {
        var text = Guard.NotEmpty(note, "Запись в истории болезни");
        _medicalHistory.Add($"{DateTime.Now:dd.MM.yyyy}: {text}");
    }

    public void DisplayRecord()
    {
        Console.WriteLine($"Медкарта №{RecordId}, пациент: {Patient.FullName}, " +
                          $"создана: {CreationDate:dd.MM.yyyy}, диагноз: {Diagnosis}");
        if (_medicalHistory.Count == 0)
        {
            Console.WriteLine("  История болезни пуста.");
            return;
        }
        foreach (var line in _medicalHistory) Console.WriteLine($"  - {line}");
    }
}

// Задача 10: медицинский анализ
public class MedicalTest
{
    public int TestId { get; }
    public string TestName { get; }
    public DateTime TestDate { get; }
    public string? Result { get; private set; }
    public Patient Patient { get; }

    public MedicalTest(int id, Patient patient, string testName, DateTime testDate)
    {
        TestId = id;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        TestName = Guard.NotEmpty(testName, "Название анализа");
        TestDate = testDate.Date;
    }

    public void AddResult(string result)
    {
        if (!string.IsNullOrEmpty(Result))
            throw new InvalidOperationException("Результат уже внесён. Используйте UpdateResult().");
        Result = Guard.NotEmpty(result, "Результат");
    }

    public void UpdateResult(string newResult)
    {
        if (string.IsNullOrEmpty(Result))
            throw new InvalidOperationException("Результата ещё нет. Используйте AddResult().");
        Result = Guard.NotEmpty(newResult, "Результат");
    }

    public void DisplayResult()
    {
        Console.WriteLine($"Анализ №{TestId}: {TestName}, пациент: {Patient.FullName}, " +
                          $"дата: {TestDate:dd.MM.yyyy}, результат: {(string.IsNullOrEmpty(Result) ? "ожидается" : Result)}");
    }
}

// Задача 21: оплата
public class Payment
{
    public int PaymentId { get; }
    public Patient Patient { get; }
    public MedicalService Service { get; }
    public decimal Amount { get; }
    public DateTime? PaymentDate { get; private set; }
    public PaymentStatus PaymentStatus { get; private set; } = PaymentStatus.Pending;

    public Payment(int id, Patient patient, MedicalService service, decimal amount)
    {
        PaymentId = id;
        Patient = patient ?? throw new ArgumentNullException(nameof(patient));
        Service = service ?? throw new ArgumentNullException(nameof(service));
        Amount = Guard.Positive(amount, "Сумма платежа");
    }

    public void MakePayment()
    {
        if (PaymentStatus != PaymentStatus.Pending)
            throw new InvalidOperationException("Платёж уже проведён или возвращён.");
        PaymentStatus = PaymentStatus.Paid;
        PaymentDate = DateTime.Now;
    }

    public void RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid)
            throw new InvalidOperationException("Вернуть можно только оплаченный платёж.");
        PaymentStatus = PaymentStatus.Refunded;
    }

    public string StatusText => PaymentStatus switch
    {
        PaymentStatus.Pending => "Ожидает оплаты",
        PaymentStatus.Paid => "Оплачен",
        PaymentStatus.Refunded => "Возвращён",
        _ => PaymentStatus.ToString()
    };

    public void DisplayPayment()
    {
        Console.WriteLine($"Платёж №{PaymentId}: {Patient.FullName}, «{Service.ServiceName}», " +
                          $"{Amount:N0} тг, {StatusText}" +
                          (PaymentDate.HasValue ? $", {PaymentDate:dd.MM.yyyy HH:mm}" : ""));
    }
}

// Задача 22: назначение
public class Prescription
{
    public int PrescriptionId { get; }
    public Patient Patient { get; }
    public Doctor Doctor { get; }
    public string MedicationName { get; private set; } = "";
    public string Dosage { get; private set; } = "";
    public int Duration { get; private set; } // дней

    private Prescription(int id, Patient patient, Doctor doctor)
    {
        PrescriptionId = id;
        Patient = patient;
        Doctor = doctor;
    }

    public static Prescription CreatePrescription(int id, Patient patient, Doctor doctor,
                                                  string medicationName, string dosage, int durationDays)
    {
        ArgumentNullException.ThrowIfNull(patient);
        ArgumentNullException.ThrowIfNull(doctor);
        var prescription = new Prescription(id, patient, doctor);
        prescription.UpdatePrescription(medicationName, dosage, durationDays);
        return prescription;
    }

    public void UpdatePrescription(string medicationName, string dosage, int durationDays)
    {
        var med = Guard.NotEmpty(medicationName, "Препарат");
        var dose = Guard.NotEmpty(dosage, "Дозировка");
        var days = Guard.Positive(durationDays, "Длительность курса");
        MedicationName = med;
        Dosage = dose;
        Duration = days;
    }

    public void DisplayPrescription()
    {
        Console.WriteLine($"Назначение №{PrescriptionId}: {Patient.FullName}, врач: {Doctor.FullName}, " +
                          $"препарат: {MedicationName}, дозировка: {Dosage}, курс: {Duration} дн.");
    }
}

// Управляющий класс: коллекции и операции портала
public class MedicalPortal
{
    private readonly List<Patient> _patients = new();
    private readonly List<Doctor> _doctors = new();
    private readonly List<Department> _departments = new();
    private readonly List<MedicalService> _services = new();
    private readonly List<Appointment> _appointments = new();
    private readonly List<MedicalTest> _tests = new();
    private readonly List<Prescription> _prescriptions = new();
    private readonly List<Payment> _payments = new();

    private int _nextPatientId = 1, _nextDoctorId = 1, _nextDepartmentId = 1, _nextServiceId = 1,
                _nextAppointmentId = 1, _nextTestId = 1, _nextPrescriptionId = 1, _nextPaymentId = 1;

    public IReadOnlyList<Patient> Patients => _patients;
    public IReadOnlyList<Doctor> Doctors => _doctors;
    public IReadOnlyList<Department> Departments => _departments;
    public IReadOnlyList<MedicalService> Services => _services;
    public IReadOnlyList<Appointment> Appointments => _appointments;

    public Patient AddPatient(string fullName, DateTime birthDate, string phone, string email, string address)
    {
        var patient = new Patient(_nextPatientId, fullName, birthDate, phone, email, address);
        _nextPatientId++;
        _patients.Add(patient);
        return patient;
    }

    public Doctor AddDoctor(string fullName, DateTime birthDate, string specialization,
                            int experience, int cabinet, decimal salary, Department? department = null)
    {
        var doctor = new Doctor(_nextDoctorId, fullName, birthDate, specialization, experience, cabinet, salary);
        _nextDoctorId++;
        _doctors.Add(doctor);
        department?.AddDoctor(doctor);
        return doctor;
    }

    public Department AddDepartment(string name, int floor, string phone)
    {
        var department = new Department(_nextDepartmentId, name, floor, phone);
        _nextDepartmentId++;
        _departments.Add(department);
        return department;
    }

    public MedicalService AddService(string name, string description, decimal price, int durationMinutes)
    {
        var service = new MedicalService(_nextServiceId, name, description, price, durationMinutes);
        _nextServiceId++;
        _services.Add(service);
        return service;
    }

    public Patient? FindPatientById(int id) => _patients.FirstOrDefault(p => p.PatientId == id);
    public Doctor? FindDoctorById(int id) => _doctors.FirstOrDefault(d => d.DoctorId == id);
    public Department? FindDepartmentById(int id) => _departments.FirstOrDefault(d => d.DepartmentId == id);
    public MedicalService? FindServiceById(int id) => _services.FirstOrDefault(s => s.ServiceId == id);
    public Appointment? FindAppointmentById(int id) => _appointments.FirstOrDefault(a => a.AppointmentId == id);

    public List<Patient> SearchPatientsByName(string query)
    {
        if (string.IsNullOrWhiteSpace(query)) return new List<Patient>();
        return _patients
            .Where(p => p.FullName.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    public List<Patient> SearchPatientsByPhone(string query)
    {
        var digits = Digits(query);
        if (digits.Length == 0) return new List<Patient>();
        return _patients.Where(p => Digits(p.PhoneNumber).Contains(digits)).ToList();
    }

    private static string Digits(string text) => new string(text.Where(char.IsDigit).ToArray());

    public Appointment? BookAppointment(Patient patient, Doctor doctor, DateTime date, TimeSpan time, out string error)
    {
        var appointment = Appointment.CreateAppointment(_nextAppointmentId, patient, doctor, date, time, out error);
        if (appointment != null)
        {
            _nextAppointmentId++;
            _appointments.Add(appointment);
        }
        return appointment;
    }

    public MedicalTest AddTest(Patient patient, string testName, DateTime date, string? result)
    {
        var test = new MedicalTest(_nextTestId, patient, testName, date);
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);
        _nextTestId++;
        _tests.Add(test);
        return test;
    }

    public Prescription AddPrescription(Patient patient, Doctor doctor, string medication, string dosage, int days)
    {
        var prescription = Prescription.CreatePrescription(_nextPrescriptionId, patient, doctor, medication, dosage, days);
        _nextPrescriptionId++;
        _prescriptions.Add(prescription);
        return prescription;
    }

    public Payment PayForService(Patient patient, MedicalService service)
    {
        var payment = new Payment(_nextPaymentId, patient, service, service.CalculatePrice());
        payment.MakePayment();
        _nextPaymentId++;
        _payments.Add(payment);
        return payment;
    }

    // Задача 24: статистика
    public int PatientsCount => _patients.Count;
    public int DoctorsCount => _doctors.Count;
    public int AppointmentsCount => _appointments.Count;
    public int CompletedAppointmentsCount => _appointments.Count(a => a.Status == AppointmentStatus.Completed);
    public decimal TotalPaidAmount => _payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).Sum(p => p.Amount);

    // Демонстрационные данные
    public void SeedDemoData()
    {
        var therapy = AddDepartment("Терапия", 2, "+7 7172 00-00-01");
        var cardio = AddDepartment("Кардиология", 3, "+7 7172 00-00-02");

        var ivanov = AddDoctor("Иванов Сергей Петрович", new DateTime(1980, 5, 14), "Терапевт", 15, 201, 300000m, therapy);
        var petrova = AddDoctor("Петрова Анна Игоревна", new DateTime(1985, 9, 2), "Кардиолог", 10, 305, 350000m, cardio);
        therapy.HeadDoctor = ivanov;
        cardio.HeadDoctor = petrova;

        AddService("Консультация терапевта", "Первичный приём", 8000m, 30);
        AddService("Консультация кардиолога", "Приём с ЭКГ", 12000m, 45);
        AddService("Общий анализ крови", "Лабораторное исследование", 3500m, 15);

        AddPatient("Сидоров Алексей Николаевич", new DateTime(1992, 3, 21), "+7 701 111-22-33", "sidorov@mail.kz", "г. Астана, ул. Абая 10");
    }
}